# College Event Registration System

A complete web application built with **Flask, SQLite, HTML5, Tailwind CSS, and Bootstrap** following the **Frosted Glass** design aesthetic.

Designed for college symposiums and inter-collegiate competitions where **exactly 12 students** from the same college register as one team across **4 sub-events**.

---

## Key Features

1. **Strict 12-Member Team Validation**:
   - Accepts college name, team leader contact info, and mandatory details for **exactly 12 students**.
   - Validates that all email addresses are well-formed and unique across members and database records.
   - Requires department and year of study for each member.
   - Allows selecting sub-events (Sub-event 1, Sub-event 2, Sub-event 3, Sub-event 4) per member.

2. **Automatic Unique Team Name Generator**:
   - Generates memorable team names using college prefix and distinct words/codes (e.g., `Imperial Thunder Hawks`, `ABC-2026-Team-8472`, `MIT-Summit-X492`).
   - Guarantees database uniqueness.
   - Assigns a unique Registration ID (`REG-2026-XXXXX`).

3. **Registration Confirmation Page**:
   - Displays printable/downloadable team registration receipt with unique team name, registration ID, college, team leader contacts, and 12-member squad cards.

4. **Protected Organizer Admin Portal**:
   - Accessible via simple password authentication (`admin123`).
   - Overview metrics: Total Teams, Total Registered Students, Sub-event selection breakdown.
   - Search teams by team name, college name, registration ID, or leader email.
   - Member roster inspection modal.
   - Export full team and member dataset to CSV (`college_event_registrations.csv`).

5. **Frosted Glass Aesthetic**:
   - Slate background canvas with glowing indigo and emerald ambient light orbs.
   - Glassmorphism backdrop-blurred containers (`bg-white/5 backdrop-blur-xl border border-white/10`).
   - Vibrant color badges for each sub-event.

---

## Project Structure

```text
├── app.py                  # Main Flask web server & route handlers
├── database.py             # SQLite database manager & schemas
├── requirements.txt        # Python dependency specifications
├── README.md               # Beginner guide & documentation
├── templates/              # HTML Jinja templates
│   ├── base.html           # Master layout template (Frosted Glass)
│   ├── index.html          # Registration form (12 members + generator)
│   ├── success.html        # Registration receipt & team badge showcase
│   ├── admin.html          # Admin management dashboard
│   └── admin_login.html    # Password login for organizer admin
└── static/                 # Static assets
    ├── css/
    │   └── style.css       # Custom frosted glass theme styles
    └── js/
        └── main.js         # Client-side 12-member validator & sample prefiller
```

---

## Beginner-Friendly Setup Instructions

### Prerequisites
- Python 3.8 or higher installed on your computer.

### Step 1: Clone or Download Project
Open your command terminal and navigate to the project directory:
```bash
cd college-event-registration
```

### Step 2: Create a Virtual Environment (Recommended)
```bash
# On Windows:
python -m venv venv
venv\Scripts\activate

# On macOS/Linux:
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Flask Application
```bash
python app.py
```

### Step 5: Open in Your Browser
Visit the following URL in your web browser:
`http://localhost:5000`

---

## Default Credentials & Admin Access

- **Admin Page URL**: `http://localhost:5000/admin`
- **Default Password**: `admin123`
