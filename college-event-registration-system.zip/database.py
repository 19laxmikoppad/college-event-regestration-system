import sqlite3
import os
import random
import string
import csv
from io import StringIO

DATABASE_FILE = 'college_events.db'

def get_db_connection():
    """Establish and return a connection to the SQLite database."""
    conn = sqlite3.connect(DATABASE_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize SQLite tables for teams, members, and event_selections."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Table for Team metadata
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reg_id TEXT UNIQUE NOT NULL,
            college_name TEXT NOT NULL,
            team_name TEXT UNIQUE NOT NULL,
            leader_name TEXT NOT NULL,
            leader_email TEXT NOT NULL,
            leader_phone TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Table for 12 Team Members
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            team_id INTEGER NOT NULL,
            member_number INTEGER NOT NULL,
            full_name TEXT NOT NULL,
            college_email TEXT UNIQUE NOT NULL,
            phone_number TEXT NOT NULL,
            department TEXT NOT NULL,
            year_of_study TEXT NOT NULL,
            FOREIGN KEY (team_id) REFERENCES teams (id) ON DELETE CASCADE
        )
    ''')

    # Table for Sub-event selections per member
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS event_selections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER NOT NULL,
            sub_event TEXT NOT NULL,
            FOREIGN KEY (member_id) REFERENCES members (id) ON DELETE CASCADE
        )
    ''')

    conn.commit()
    conn.close()

def generate_registration_id():
    """Generate a unique registration ID (e.g., REG-2026-X8F92)."""
    random_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"REG-2026-{random_code}"

def generate_unique_team_name(college_name):
    """Generate a memorable, unique team name using college name + descriptor."""
    adjectives = [
        "Thunder", "Apex", "Quantum", "Nexus", "Titan", "Vanguard", 
        "Cyber", "Starlight", "Hyper", "Solar", "Aero", "Pulse",
        "Summit", "Velocity", "Orbital", "Spectral", "Phoenix"
    ]
    nouns = [
        "Hawks", "Knights", "Innovators", "Squad", "Warriors", "Pioneers",
        "Falcons", "Titans", "Mavericks", "Wolves", "Dragons", "Vectors"
    ]
    
    # Extract clean college abbreviation or short name
    words = [w.capitalize() for w in college_name.strip().split() if w.lower() not in ['of', 'and', 'for', 'the']]
    if len(words) > 1:
        prefix = "".join([w[0] for w in words])
    else:
        prefix = words[0][:6].upper() if words else "COLLEGE"

    conn = get_db_connection()
    cursor = conn.cursor()

    for _ in range(100):
        adj = random.choice(adjectives)
        noun = random.choice(nouns)
        num = random.randint(100, 999)
        
        # Format variation 1: "ABC Thunder Hawks"
        # Format variation 2: "ABC-2026-Team-8472"
        # Format variation 3: "Imperial-Summit-2026-X492"
        choice = random.randint(1, 3)
        if choice == 1:
            team_name = f"{prefix} {adj} {noun}"
        elif choice == 2:
            team_name = f"{prefix}-2026-Team-{num}"
        else:
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
            team_name = f"{prefix}-{adj}-{code}"

        cursor.execute("SELECT id FROM teams WHERE team_name = ?", (team_name,))
        if not cursor.fetchone():
            conn.close()
            return team_name

    # Fallback with timestamp code
    code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    conn.close()
    return f"{prefix}-Squad-{code}"

def check_existing_emails(email_list):
    """Check if any emails in the given list already exist in the database."""
    conn = get_db_connection()
    cursor = conn.cursor()
    placeholders = ','.join(['?'] * len(email_list))
    cursor.execute(f"SELECT college_email FROM members WHERE college_email IN ({placeholders})", email_list)
    existing = [row['college_email'] for row in cursor.fetchall()]
    conn.close()
    return existing

def register_team(college_name, leader_name, leader_email, leader_phone, members_data):
    """
    Registers a team with exactly 12 members and their selected sub-events.
    Returns (success, result_data_or_error_message).
    """
    if len(members_data) != 12:
        return False, "Registration requires details for exactly 12 members."

    # Validate emails uniqueness inside the registration payload
    emails = [m['college_email'].strip().lower() for m in members_data]
    if len(set(emails)) != 12:
        return False, "Duplicate email addresses found within the team member list."

    # Check database for pre-existing member emails
    existing_in_db = check_existing_emails(emails)
    if existing_in_db:
        return False, f"The following student email(s) are already registered: {', '.join(existing_in_db)}"

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        reg_id = generate_registration_id()
        team_name = generate_unique_team_name(college_name)

        cursor.execute('''
            INSERT INTO teams (reg_id, college_name, team_name, leader_name, leader_email, leader_phone)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (reg_id, college_name, team_name, leader_name, leader_email, leader_phone))

        team_id = cursor.lastrowid

        for idx, m in enumerate(members_data, start=1):
            cursor.execute('''
                INSERT INTO members (team_id, member_number, full_name, college_email, phone_number, department, year_of_study)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (team_id, idx, m['full_name'].strip(), m['college_email'].strip().lower(), m['phone_number'].strip(), m['department'].strip(), m['year_of_study'].strip()))

            member_id = cursor.lastrowid

            for sub_event in m.get('sub_events', []):
                cursor.execute('''
                    INSERT INTO event_selections (member_id, sub_event)
                    VALUES (?, ?)
                ''', (member_id, sub_event))

        conn.commit()
        conn.close()

        return True, {
            'reg_id': reg_id,
            'team_name': team_name,
            'college_name': college_name,
            'leader_name': leader_name,
            'leader_email': leader_email,
            'leader_phone': leader_phone
        }

    except Exception as e:
        conn.rollback()
        conn.close()
        return False, f"Database registration failed: {str(e)}"

def get_team_by_reg_id(reg_id):
    """Retrieve full details for a registered team by registration ID."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM teams WHERE reg_id = ?", (reg_id,))
    team = cursor.fetchone()

    if not team:
        conn.close()
        return None

    team_dict = dict(team)

    cursor.execute("SELECT * FROM members WHERE team_id = ? ORDER BY member_number ASC", (team_dict['id'],))
    members = cursor.fetchall()

    members_list = []
    for m in members:
        m_dict = dict(m)
        cursor.execute("SELECT sub_event FROM event_selections WHERE member_id = ?", (m_dict['id'],))
        events = [row['sub_event'] for row in cursor.fetchall()]
        m_dict['sub_events'] = events
        members_list.append(m_dict)

    team_dict['members'] = members_list
    conn.close()
    return team_dict

def get_all_teams(search_query=None):
    """Retrieve all registered teams with optional search query filter."""
    conn = get_db_connection()
    cursor = conn.cursor()

    if search_query:
        query = "%" + search_query.strip() + "%"
        cursor.execute('''
            SELECT * FROM teams 
            WHERE team_name LIKE ? OR college_name LIKE ? OR leader_email LIKE ? OR leader_name LIKE ? OR reg_id LIKE ?
            ORDER BY created_at DESC
        ''', (query, query, query, query, query))
    else:
        cursor.execute("SELECT * FROM teams ORDER BY created_at DESC")

    teams = cursor.fetchall()
    result = []

    for t in teams:
        t_dict = dict(t)
        cursor.execute("SELECT * FROM members WHERE team_id = ? ORDER BY member_number ASC", (t_dict['id'],))
        members = cursor.fetchall()
        
        m_list = []
        for m in members:
            m_dict = dict(m)
            cursor.execute("SELECT sub_event FROM event_selections WHERE member_id = ?", (m_dict['id'],))
            m_dict['sub_events'] = [row['sub_event'] for row in cursor.fetchall()]
            m_list.append(m_dict)

        t_dict['members'] = m_list
        result.append(t_dict)

    conn.close()
    return result

def get_summary_stats():
    """Retrieve summary metrics for the admin dashboard."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) as total_teams FROM teams")
    total_teams = cursor.fetchone()['total_teams']

    cursor.execute("SELECT COUNT(*) as total_members FROM members")
    total_members = cursor.fetchone()['total_members']

    # Sub-event breakdown counts
    cursor.execute("SELECT sub_event, COUNT(*) as cnt FROM event_selections GROUP BY sub_event")
    event_counts = {row['sub_event']: row['cnt'] for row in cursor.fetchall()}

    conn.close()
    return {
        'total_teams': total_teams,
        'total_members': total_members,
        'event_counts': event_counts
    }

def export_teams_csv():
    """Generates CSV string containing all teams and member event registrations."""
    teams = get_all_teams()
    
    output = StringIO()
    writer = csv.writer(output)

    # Header
    writer.writerow([
        'Registration ID', 'Team Name', 'College Name', 'Leader Name', 'Leader Email', 'Leader Phone',
        'Member Number', 'Member Full Name', 'College Email', 'Member Phone', 'Department', 'Year of Study', 'Sub-Events Selected'
    ])

    for team in teams:
        for member in team['members']:
            events_str = ", ".join(member['sub_events']) if member['sub_events'] else "None"
            writer.writerow([
                team['reg_id'],
                team['team_name'],
                team['college_name'],
                team['leader_name'],
                team['leader_email'],
                team['leader_phone'],
                member['member_number'],
                member['full_name'],
                member['college_email'],
                member['phone_number'],
                member['department'],
                member['year_of_study'],
                events_str
            ])

    return output.getvalue()
