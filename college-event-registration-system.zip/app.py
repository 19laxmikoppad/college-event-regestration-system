import os
import re
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, Response, session
from database import init_db, register_team, get_team_by_reg_id, get_all_teams, get_summary_stats, export_teams_csv

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'college_event_secret_key_2026')

# Simple Admin Password (as required)
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')

# Initialize SQLite database on startup
init_db()

EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

SUB_EVENTS = [
    {"id": "event1", "name": "Sub-event 1", "title": "Sub-event 1: Algorithm & Code Odyssey", "badge": "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"},
    {"id": "event2", "name": "Sub-event 2", "title": "Sub-event 2: Robo Wars & Embedded Systems", "badge": "bg-purple-500/20 text-purple-300 border-purple-500/30"},
    {"id": "event3", "name": "Sub-event 3", "title": "Sub-event 3: Data Analytics & AI Sprint", "badge": "bg-blue-500/20 text-blue-300 border-blue-500/30"},
    {"id": "event4", "name": "Sub-event 4", "title": "Sub-event 4: UI/UX & Product Design Challenge", "badge": "bg-amber-500/20 text-amber-300 border-amber-500/30"}
]

@app.route('/')
def index():
    """Renders the College Event Team Registration Form."""
    return render_template('index.html', sub_events=SUB_EVENTS)

@app.route('/register', methods=['POST'])
def register():
    """Handles submission for team registration (12 members)."""
    try:
        college_name = request.form.get('college_name', '').strip()
        leader_name = request.form.get('leader_name', '').strip()
        leader_email = request.form.get('leader_email', '').strip().lower()
        leader_phone = request.form.get('leader_phone', '').strip()

        # Input validations
        if not all([college_name, leader_name, leader_email, leader_phone]):
            flash("College Name, Team Leader Name, Email, and Phone are required fields.", "error")
            return redirect(url_for('index'))

        if not re.match(EMAIL_REGEX, leader_email):
            flash("Invalid Team Leader Email address format.", "error")
            return redirect(url_for('index'))

        members_data = []
        emails_seen = set()

        # Parse details for exactly 12 members
        for i in range(1, 13):
            full_name = request.form.get(f'member_{i}_name', '').strip()
            email = request.form.get(f'member_{i}_email', '').strip().lower()
            phone = request.form.get(f'member_{i}_phone', '').strip()
            dept = request.form.get(f'member_{i}_dept', '').strip()
            year = request.form.get(f'member_{i}_year', '').strip()
            
            # Selected sub-events for member i
            selections = request.form.getlist(f'member_{i}_events')

            if not all([full_name, email, phone, dept, year]):
                flash(f"All details for Member {i} must be provided.", "error")
                return redirect(url_for('index'))

            if not re.match(EMAIL_REGEX, email):
                flash(f"Invalid email address format for Member {i} ({full_name}).", "error")
                return redirect(url_for('index'))

            if email in emails_seen:
                flash(f"Duplicate email found in member list: {email}. All 12 members must have unique email IDs.", "error")
                return redirect(url_for('index'))

            emails_seen.add(email)

            members_data.append({
                'full_name': full_name,
                'college_email': email,
                'phone_number': phone,
                'department': dept,
                'year_of_study': year,
                'sub_events': selections
            })

        if len(members_data) != 12:
            flash("Registration requires details for exactly 12 team members.", "error")
            return redirect(url_for('index'))

        success, result = register_team(
            college_name=college_name,
            leader_name=leader_name,
            leader_email=leader_email,
            leader_phone=leader_phone,
            members_data=members_data
        )

        if success:
            flash(f"Team '{result['team_name']}' successfully registered!", "success")
            return redirect(url_for('success', reg_id=result['reg_id']))
        else:
            flash(f"Registration Error: {result}", "error")
            return redirect(url_for('index'))

    except Exception as e:
        flash(f"An unexpected error occurred during submission: {str(e)}", "error")
        return redirect(url_for('index'))

@app.route('/success/<reg_id>')
def success(reg_id):
    """Displays registration confirmation receipt."""
    team = get_team_by_reg_id(reg_id)
    if not team:
        flash("Registration ID not found.", "error")
        return redirect(url_for('index'))

    return render_template('success.html', team=team, sub_events=SUB_EVENTS)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Admin password authentication."""
    if request.method == 'POST':
        password = request.form.get('password', '').strip()
        if password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            flash("Admin authentication successful.", "success")
            return redirect(url_for('admin'))
        else:
            flash("Invalid Admin Password. Access Denied.", "error")

    return render_template('admin_login.html')

@app.route('/admin')
def admin():
    """Admin page to view all teams, search, filter, and inspect member details."""
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))

    search_query = request.args.get('q', '').strip()
    teams = get_all_teams(search_query=search_query)
    stats = get_summary_stats()

    return render_template('admin.html', teams=teams, search_query=search_query, stats=stats, sub_events=SUB_EVENTS)

@app.route('/admin/logout')
def admin_logout():
    """Admin logout."""
    session.pop('admin_logged_in', None)
    flash("You have been logged out of the Admin panel.", "info")
    return redirect(url_for('admin_login'))

@app.route('/admin/export')
def admin_export():
    """Export registration data to CSV file."""
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))

    csv_data = export_teams_csv()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=college_event_registrations.csv"}
    )

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
