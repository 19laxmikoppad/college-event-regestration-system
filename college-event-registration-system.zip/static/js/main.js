document.addEventListener('DOMContentLoaded', () => {
  const collegeInput = document.getElementById('college_name');
  const teamPreview = document.getElementById('team-name-preview');
  const autofillBtn = document.getElementById('btn-autofill');
  const form = document.getElementById('registrationForm');
  const progressCounter = document.getElementById('progress-counter');
  const validationSummaryText = document.getElementById('validation-summary-text');

  // Realistic sample data for quick auto-fill test of 12 members
  const SAMPLE_COLLEGE = "Imperial Institute of Technology";
  const SAMPLE_LEADER = {
    name: "Sarah Jenkins",
    email: "s.jenkins@imperial.edu",
    phone: "9876543210"
  };

  const SAMPLE_MEMBERS = [
    { name: "Marcus Vane", email: "m.vane@imperial.edu", phone: "9871112233", dept: "Computer Science", year: "Year 3", events: ["Sub-event 1", "Sub-event 3"] },
    { name: "Elena Ruiz", email: "e.ruiz@imperial.edu", phone: "9871112234", dept: "Artificial Intelligence", year: "Year 2", events: ["Sub-event 2"] },
    { name: "David Oh", email: "d.oh@imperial.edu", phone: "9871112235", dept: "Mechanical Eng", year: "Year 4", events: ["Sub-event 3", "Sub-event 4"] },
    { name: "Siddharth Kapoor", email: "s.kapoor@imperial.edu", phone: "9871112236", dept: "Computer Science", year: "Year 3", events: ["Sub-event 1"] },
    { name: "Liam West", email: "l.west@imperial.edu", phone: "9871112237", dept: "Electrical & Electronics", year: "Year 2", events: ["Sub-event 4"] },
    { name: "Nina Kim", email: "n.kim@imperial.edu", phone: "9871112238", dept: "Artificial Intelligence", year: "Year 3", events: ["Sub-event 2"] },
    { name: "Tom Brady", email: "t.brady@imperial.edu", phone: "9871112239", dept: "Computer Science", year: "Year 1", events: ["Sub-event 1"] },
    { name: "Ananya Patel", email: "a.patel@imperial.edu", phone: "9871112240", dept: "Electrical & Electronics", year: "Year 3", events: ["Sub-event 3"] },
    { name: "James Smith", email: "j.smith@imperial.edu", phone: "9871112241", dept: "Mechanical Eng", year: "Year 2", events: ["Sub-event 2"] },
    { name: "Michael Scott", email: "m.scott@imperial.edu", phone: "9871112242", dept: "Business Admin", year: "Year 4", events: ["Sub-event 4"] },
    { name: "Pam Beesly", email: "p.beesly@imperial.edu", phone: "9871112243", dept: "Computer Science", year: "Year 2", events: ["Sub-event 1"] },
    { name: "Dwight Schrute", email: "d.schrute@imperial.edu", phone: "9871112244", dept: "Civil Eng", year: "Year 4", events: ["Sub-event 2"] }
  ];

  // Update Team Name Preview dynamically based on College Name
  if (collegeInput && teamPreview) {
    collegeInput.addEventListener('input', () => {
      const val = collegeInput.value.trim();
      if (val) {
        teamPreview.textContent = `${val} Thunder Hawks / ${val.slice(0, 4).toUpperCase()}-2026-Team-8472`;
      } else {
        teamPreview.textContent = '[College Name] Thunder Hawks';
      }
      updateValidationProgress();
    });
  }

  // Update Progress Counter for 12 filled members
  function updateValidationProgress() {
    if (!form) return;
    let filledCount = 0;

    for (let i = 1; i <= 12; i++) {
      const nameInput = form.querySelector(`input[name="member_${i}_name"]`);
      const emailInput = form.querySelector(`input[name="member_${i}_email"]`);
      const phoneInput = form.querySelector(`input[name="member_${i}_phone"]`);
      const deptInput = form.querySelector(`select[name="member_${i}_dept"]`);
      const yearInput = form.querySelector(`select[name="member_${i}_year"]`);
      
      const statusTag = document.querySelector(`.status-tag-${i}`);
      const pill = document.querySelector(`.pill-member-${i}`);

      if (nameInput?.value.trim() && emailInput?.value.trim() && phoneInput?.value.trim() && deptInput?.value && yearInput?.value) {
        filledCount++;
        if (statusTag) {
          statusTag.textContent = "Verified";
          statusTag.className = `text-[10px] uppercase font-bold text-emerald-400 tracking-wider status-tag-${i}`;
        }
        if (pill) pill.classList.add('pill-active');
      } else {
        if (statusTag) {
          statusTag.textContent = "Pending";
          statusTag.className = `text-[10px] uppercase font-bold text-slate-400 tracking-wider status-tag-${i}`;
        }
        if (pill) pill.classList.remove('pill-active');
      }
    }

    if (progressCounter) {
      progressCounter.textContent = `${filledCount} / 12`;
    }

    if (validationSummaryText) {
      if (filledCount === 12) {
        validationSummaryText.textContent = "All 12 member profiles verified & ready for team registration!";
        validationSummaryText.className = "text-sm text-emerald-300 font-medium";
      } else {
        validationSummaryText.textContent = `Completed ${filledCount} of 12 required member details.`;
        validationSummaryText.className = "text-sm text-slate-300";
      }
    }
  }

  // Attach input event listeners for real-time validation feedback
  if (form) {
    form.querySelectorAll('input, select').forEach(el => {
      el.addEventListener('input', updateValidationProgress);
      el.addEventListener('change', updateValidationProgress);
    });
  }

  // Auto-Fill sample data button click handler
  if (autofillBtn && form) {
    autofillBtn.addEventListener('click', () => {
      document.getElementById('college_name').value = SAMPLE_COLLEGE;
      document.getElementById('leader_name').value = SAMPLE_LEADER.name;
      document.getElementById('leader_email').value = SAMPLE_LEADER.email;
      document.getElementById('leader_phone').value = SAMPLE_LEADER.phone;

      teamPreview.textContent = `${SAMPLE_COLLEGE} Summit-2026-X492`;

      SAMPLE_MEMBERS.forEach((m, idx) => {
        const i = idx + 1;
        const nameInput = form.querySelector(`input[name="member_${i}_name"]`);
        const emailInput = form.querySelector(`input[name="member_${i}_email"]`);
        const phoneInput = form.querySelector(`input[name="member_${i}_phone"]`);
        const deptInput = form.querySelector(`select[name="member_${i}_dept"]`);
        const yearInput = form.querySelector(`select[name="member_${i}_year"]`);

        if (nameInput) nameInput.value = m.name;
        if (emailInput) emailInput.value = m.email;
        if (phoneInput) phoneInput.value = m.phone;
        if (deptInput) deptInput.value = m.dept;
        if (yearInput) yearInput.value = m.year;

        // Check checkboxes
        const checkboxes = form.querySelectorAll(`input[name="member_${i}_events"]`);
        checkboxes.forEach(cb => {
          cb.checked = m.events.includes(cb.value);
        });
      });

      updateValidationProgress();
    });
  }

  updateValidationProgress();
});
