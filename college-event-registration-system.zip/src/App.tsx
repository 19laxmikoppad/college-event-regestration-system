import React, { useState, useEffect } from 'react';
import { 
  Users, ShieldCheck, Download, Search, CheckCircle, AlertCircle, 
  Sparkles, Lock, ArrowRight, Printer, RefreshCw, Layers, Award, Check
} from 'lucide-react';
import { 
  registerTeam, getTeamByRegId, getAllTeams, getSummaryStats, exportTeamsCSV,
  TeamRecord, MemberInput 
} from './lib/db';

const SUB_EVENTS = [
  { id: 'Sub-event 1', name: 'Sub-event 1', label: 'Sub-event 1: Code Odyssey', badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
  { id: 'Sub-event 2', name: 'Sub-event 2', label: 'Sub-event 2: Robo Wars', badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
  { id: 'Sub-event 3', name: 'Sub-event 3', label: 'Sub-event 3: Data Sprint', badge: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  { id: 'Sub-event 4', name: 'Sub-event 4', label: 'Sub-event 4: UI/UX Challenge', badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30' }
];

const DEPARTMENTS = [
  'Computer Science',
  'Artificial Intelligence',
  'Electrical & Electronics',
  'Mechanical Eng',
  'Civil Eng',
  'Business Admin'
];

const YEARS = ['Year 1', 'Year 2', 'Year 3', 'Year 4'];

const SAMPLE_MEMBERS_DATA: MemberInput[] = [
  { full_name: "Marcus Vane", college_email: "m.vane@imperial.edu", phone_number: "9871112233", department: "Computer Science", year_of_study: "Year 3", sub_events: ["Sub-event 1", "Sub-event 3"] },
  { full_name: "Elena Ruiz", college_email: "e.ruiz@imperial.edu", phone_number: "9871112234", department: "Artificial Intelligence", year_of_study: "Year 2", sub_events: ["Sub-event 2"] },
  { full_name: "David Oh", college_email: "d.oh@imperial.edu", phone_number: "9871112235", department: "Mechanical Eng", year_of_study: "Year 4", sub_events: ["Sub-event 3", "Sub-event 4"] },
  { full_name: "Siddharth Kapoor", college_email: "s.kapoor@imperial.edu", phone_number: "9871112236", department: "Computer Science", year_of_study: "Year 3", sub_events: ["Sub-event 1"] },
  { full_name: "Liam West", college_email: "l.west@imperial.edu", phone_number: "9871112237", department: "Electrical & Electronics", year_of_study: "Year 2", sub_events: ["Sub-event 4"] },
  { full_name: "Nina Kim", college_email: "n.kim@imperial.edu", phone_number: "9871112238", department: "Artificial Intelligence", year_of_study: "Year 3", sub_events: ["Sub-event 2"] },
  { full_name: "Tom Brady", college_email: "t.brady@imperial.edu", phone_number: "9871112239", department: "Computer Science", year_of_study: "Year 1", sub_events: ["Sub-event 1"] },
  { full_name: "Ananya Patel", college_email: "a.patel@imperial.edu", phone_number: "9871112240", department: "Electrical & Electronics", year_of_study: "Year 3", sub_events: ["Sub-event 3"] },
  { full_name: "James Smith", college_email: "j.smith@imperial.edu", phone_number: "9871112241", department: "Mechanical Eng", year_of_study: "Year 2", sub_events: ["Sub-event 2"] },
  { full_name: "Michael Scott", college_email: "m.scott@imperial.edu", phone_number: "9871112242", department: "Business Admin", year_of_study: "Year 4", sub_events: ["Sub-event 4"] },
  { full_name: "Pam Beesly", college_email: "p.beesly@imperial.edu", phone_number: "9871112243", department: "Computer Science", year_of_study: "Year 2", sub_events: ["Sub-event 1"] },
  { full_name: "Dwight Schrute", college_email: "d.schrute@imperial.edu", phone_number: "9871112244", department: "Civil Eng", year_of_study: "Year 4", sub_events: ["Sub-event 2"] }
];

export default function App() {
  const [view, setView] = useState<'form' | 'success' | 'admin'>('form');
  const [activeRegId, setActiveRegId] = useState<string | null>(null);
  const [registeredTeam, setRegisteredTeam] = useState<TeamRecord | null>(null);

  // Form State
  const [collegeName, setCollegeName] = useState('');
  const [leaderName, setLeaderName] = useState('');
  const [leaderEmail, setLeaderEmail] = useState('');
  const [leaderPhone, setLeaderPhone] = useState('');
  const [members, setMembers] = useState<MemberInput[]>(
    Array.from({ length: 12 }, () => ({
      full_name: '',
      college_email: '',
      phone_number: '',
      department: '',
      year_of_study: '',
      sub_events: []
    }))
  );

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Admin State
  const [adminAuth, setAdminAuth] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState<string | null>(null);
  const [adminSearch, setAdminSearch] = useState('');
  const [adminTeams, setAdminTeams] = useState<TeamRecord[]>([]);
  const [adminStats, setAdminStats] = useState<any>(null);
  const [selectedAdminTeam, setSelectedAdminTeam] = useState<TeamRecord | null>(null);

  // Load team on success view change
  useEffect(() => {
    if (view === 'success' && activeRegId) {
      getTeamByRegId(activeRegId).then(team => {
        if (team) setRegisteredTeam(team);
      });
    }
  }, [view, activeRegId]);

  // Load admin data
  useEffect(() => {
    if (view === 'admin' && adminAuth) {
      loadAdminData(adminSearch);
    }
  }, [view, adminAuth, adminSearch]);

  const loadAdminData = async (query = '') => {
    const teams = await getAllTeams(query);
    const stats = await getSummaryStats();
    setAdminTeams(teams);
    setAdminStats(stats);
  };

  const handleAutoFill = () => {
    setCollegeName("Imperial Institute of Technology");
    setLeaderName("Sarah Jenkins");
    setLeaderEmail("s.jenkins@imperial.edu");
    setLeaderPhone("9876543210");
    setMembers(JSON.parse(JSON.stringify(SAMPLE_MEMBERS_DATA)));
    setErrorMsg(null);
  };

  const handleMemberChange = (index: number, field: keyof MemberInput, value: any) => {
    const updated = [...members];
    updated[index] = { ...updated[index], [field]: value };
    setMembers(updated);
  };

  const toggleSubEvent = (memberIndex: number, subEvent: string) => {
    const updated = [...members];
    const currentEvents = updated[memberIndex].sub_events;
    if (currentEvents.includes(subEvent)) {
      updated[memberIndex].sub_events = currentEvents.filter(e => e !== subEvent);
    } else {
      updated[memberIndex].sub_events = [...currentEvents, subEvent];
    }
    setMembers(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!collegeName.trim() || !leaderName.trim() || !leaderEmail.trim() || !leaderPhone.trim()) {
      setErrorMsg("College Name and Team Leader contact details are required.");
      return;
    }

    // Check all 12 members filled
    for (let i = 0; i < 12; i++) {
      const m = members[i];
      if (!m.full_name.trim() || !m.college_email.trim() || !m.phone_number.trim() || !m.department || !m.year_of_study) {
        setErrorMsg(`Please complete all required fields for Member #${i + 1} (${m.full_name || 'Name missing'}).`);
        return;
      }
    }

    setIsSubmitting(true);
    const result = await registerTeam(collegeName, leaderName, leaderEmail, leaderPhone, members);
    setIsSubmitting(false);

    if (result.success && result.team) {
      setActiveRegId(result.team.reg_id);
      setView('success');
    } else {
      setErrorMsg(result.error || "Failed to submit registration.");
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'admin123') {
      setAdminAuth(true);
      setAdminError(null);
    } else {
      setAdminError("Invalid Admin Password. Access Denied.");
    }
  };

  const handleExportCSV = async () => {
    const csvStr = await exportTeamsCSV();
    const blob = new Blob([csvStr], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'college_event_registrations.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  // Calculate filled members count
  const filledCount = members.filter(m => 
    m.full_name.trim() && m.college_email.trim() && m.phone_number.trim() && m.department && m.year_of_study
  ).length;

  return (
    <div className="bg-slate-950 text-white font-sans min-h-screen flex flex-col relative overflow-x-hidden selection:bg-emerald-400 selection:text-slate-950">

      {/* Ambient Radial Mesh Background (Frosted Glass Aesthetics) */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-950 via-slate-950 to-emerald-950 opacity-90 pointer-events-none z-0"></div>
      <div className="fixed -top-48 -left-48 w-96 h-96 bg-blue-600/30 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="fixed -bottom-48 -right-48 w-96 h-96 bg-emerald-600/20 rounded-full blur-[120px] pointer-events-none z-0"></div>

      {/* Top Header Navigation */}
      <header className="relative z-10 border-b border-white/10 bg-slate-950/70 backdrop-blur-md sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <button onClick={() => setView('form')} className="flex items-center gap-3 bg-transparent border-0 text-left cursor-pointer group">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-indigo-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-400/20 group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5 text-slate-950 font-bold" />
            </div>
            <div>
              <span className="text-emerald-400 text-[10px] font-bold tracking-[0.3em] uppercase block">Academic Championship 2026</span>
              <h1 className="text-xl font-light tracking-tight text-white m-0">College Event <span className="font-semibold text-emerald-400">Portal</span></h1>
            </div>
          </button>

          <div className="flex items-center gap-3">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-4 py-1.5 flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-400 rounded-full shadow-[0_0_8px_#34d399] animate-pulse"></div>
              <span className="text-xs font-medium text-slate-200">12 Members / Squad Required</span>
            </div>

            {view !== 'admin' ? (
              <button onClick={() => setView('admin')} className="px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Admin
              </button>
            ) : (
              <button onClick={() => setView('form')} className="px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer">
                Registration Form
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Body Layout */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">

        {/* VIEW 1: REGISTRATION FORM */}
        {view === 'form' && (
          <div className="space-y-8">
            
            {/* Intro Hero Banner */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 md:p-8 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 shadow-2xl relative overflow-hidden">
              <div className="space-y-2 max-w-2xl">
                <span className="text-emerald-400 text-xs font-bold tracking-[0.3em] uppercase">College Squad Registration</span>
                <h2 className="text-3xl md:text-4xl font-light text-white tracking-tight">Team Registration <span className="font-bold text-emerald-400">Dashboard</span></h2>
                <p className="text-slate-300 text-sm leading-relaxed">
                  Enter team details for exactly 12 students from your college. Select sub-event participation for each member.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
                <button type="button" onClick={handleAutoFill} className="px-5 py-3 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 hover:bg-indigo-500/30 text-indigo-200 font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer">
                  <Sparkles className="w-4 h-4 text-indigo-300" /> Auto-Fill Sample 12 Members
                </button>
                <div className="bg-white/10 border border-white/10 rounded-2xl p-4 text-center min-w-[140px]">
                  <div className="text-2xl font-bold text-emerald-400 font-mono">{filledCount} / 12</div>
                  <div className="text-[10px] uppercase tracking-widest text-slate-400">Members Verified</div>
                </div>
              </div>
            </div>

            {errorMsg && (
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-sm flex items-center gap-3">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">

              {/* Section 1: College & Leader Contact */}
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
                <div className="flex items-center gap-3 border-b border-white/10 pb-4">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">1</div>
                  <h3 className="text-base font-semibold text-white uppercase tracking-wider m-0">Primary Contact & College</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[11px] uppercase tracking-wider text-emerald-400 font-bold block">College Name *</label>
                    <input 
                      type="text" 
                      value={collegeName} 
                      onChange={e => setCollegeName(e.target.value)}
                      placeholder="e.g. Imperial Institute of Technology"
                      className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-400 transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] uppercase tracking-wider text-emerald-400 font-bold block">Team Leader Name *</label>
                    <input 
                      type="text" 
                      value={leaderName} 
                      onChange={e => setLeaderName(e.target.value)}
                      placeholder="e.g. Sarah Jenkins"
                      className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-400 transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] uppercase tracking-wider text-emerald-400 font-bold block">Leader Phone *</label>
                    <input 
                      type="tel" 
                      value={leaderPhone} 
                      onChange={e => setLeaderPhone(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-400 transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[11px] uppercase tracking-wider text-emerald-400 font-bold block">Leader College Email *</label>
                    <input 
                      type="email" 
                      value={leaderEmail} 
                      onChange={e => setLeaderEmail(e.target.value)}
                      placeholder="e.g. s.jenkins@imperial.edu"
                      className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-400 transition-colors"
                      required
                    />
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <label className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block">Generated Team Name</label>
                    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex items-center justify-between">
                      <span className="text-emerald-300 font-mono text-sm font-bold truncate">
                        {collegeName.trim() ? `${collegeName.trim()} Thunder Hawks` : '[College Name] Thunder Hawks'}
                      </span>
                      <span className="text-[10px] text-slate-400 uppercase tracking-widest bg-emerald-400/10 px-2 py-0.5 rounded shrink-0">Auto Generated</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 2: Member Roster Grid */}
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-sm">2</div>
                    <h3 className="text-base font-semibold text-white uppercase tracking-wider m-0">Roster Management (12 Required)</h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {members.map((m, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-4 hover:border-emerald-500/30 transition-all relative">
                      
                      <div className="flex items-center justify-between border-b border-white/10 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 font-mono font-bold text-xs flex items-center justify-center">
                            {String(idx + 1).padStart(2, '0')}
                          </div>
                          <span className="text-xs font-semibold text-white">Member #{idx + 1}</span>
                        </div>
                        <span className={`text-[10px] uppercase font-bold tracking-wider ${
                          m.full_name && m.college_email && m.phone_number && m.department && m.year_of_study 
                            ? 'text-emerald-400' 
                            : 'text-slate-400'
                        }`}>
                          {m.full_name && m.college_email && m.phone_number && m.department && m.year_of_study ? 'Verified' : 'Pending'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1 sm:col-span-2">
                          <label className="text-[10px] uppercase text-emerald-400 font-bold block">Full Name *</label>
                          <input 
                            type="text" 
                            value={m.full_name} 
                            onChange={e => handleMemberChange(idx, 'full_name', e.target.value)}
                            placeholder="Student Full Name"
                            className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] uppercase text-emerald-400 font-bold block">College Email *</label>
                          <input 
                            type="email" 
                            value={m.college_email} 
                            onChange={e => handleMemberChange(idx, 'college_email', e.target.value)}
                            placeholder="student@college.edu"
                            className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] uppercase text-emerald-400 font-bold block">Phone Number *</label>
                          <input 
                            type="tel" 
                            value={m.phone_number} 
                            onChange={e => handleMemberChange(idx, 'phone_number', e.target.value)}
                            placeholder="Phone Number"
                            className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] uppercase text-emerald-400 font-bold block">Department *</label>
                          <select 
                            value={m.department} 
                            onChange={e => handleMemberChange(idx, 'department', e.target.value)}
                            className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                            required
                          >
                            <option value="">Select Department</option>
                            {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] uppercase text-emerald-400 font-bold block">Year of Study *</label>
                          <select 
                            value={m.year_of_study} 
                            onChange={e => handleMemberChange(idx, 'year_of_study', e.target.value)}
                            className="w-full bg-slate-900 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-400"
                            required
                          >
                            <option value="">Select Year</option>
                            {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                          </select>
                        </div>
                      </div>

                      {/* Sub-Events selector */}
                      <div className="space-y-1.5 pt-2 border-t border-white/10">
                        <label className="text-[10px] uppercase text-slate-300 font-bold block">Select Sub-Events</label>
                        <div className="grid grid-cols-2 gap-2">
                          {SUB_EVENTS.map(ev => {
                            const isChecked = m.sub_events.includes(ev.name);
                            return (
                              <button
                                type="button"
                                key={ev.id}
                                onClick={() => toggleSubEvent(idx, ev.name)}
                                className={`p-2 rounded-xl border text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                                  isChecked 
                                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200 font-semibold' 
                                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                                }`}
                              >
                                <span className="text-[11px] truncate">{ev.name}</span>
                                {isChecked && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              </div>

              {/* Submit & Status Footer */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-emerald-400/10 border border-emerald-400/20 p-6 rounded-3xl backdrop-blur-xl">
                <div>
                  <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-widest mb-1">Final Summary</div>
                  <div className="text-sm text-slate-300 italic">
                    "{filledCount} of 12 members filled. Unique email check active. Ready for deployment."
                  </div>
                </div>
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-10 py-4 bg-emerald-400 text-slate-950 font-bold rounded-2xl shadow-lg shadow-emerald-400/20 hover:scale-105 active:scale-95 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" /> Registering...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" /> Complete Registration
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        )}

        {/* VIEW 2: REGISTRATION SUCCESS RECEIPT */}
        {view === 'success' && registeredTeam && (
          <div className="space-y-6 max-w-5xl mx-auto">
            
            <div className="bg-white/5 backdrop-blur-xl border border-emerald-500/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
              
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-400 text-slate-950 flex items-center justify-center font-black text-2xl shadow-lg shadow-emerald-400/30">
                    <Award className="w-8 h-8 text-slate-950" />
                  </div>
                  <div>
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold rounded-full uppercase tracking-wider border border-emerald-500/30">
                      Registration Confirmed
                    </span>
                    <h2 className="text-2xl md:text-3xl font-bold text-white mt-1 mb-0">{registeredTeam.team_name}</h2>
                    <p className="text-xs text-slate-400 m-0">College: <span className="text-slate-200 font-medium">{registeredTeam.college_name}</span></p>
                  </div>
                </div>

                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-4 text-center">
                  <span className="block text-[10px] text-slate-400 uppercase tracking-widest mb-0.5">Registration ID</span>
                  <span className="text-xl font-mono font-bold text-emerald-400">{registeredTeam.reg_id}</span>
                </div>
              </div>

              {/* Leader Metadata */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-white/5 border border-white/10 rounded-2xl p-4">
                <div>
                  <span className="text-[10px] uppercase text-slate-400 font-bold block mb-1">Team Leader</span>
                  <div className="text-sm font-semibold text-white">{registeredTeam.leader_name}</div>
                  <div className="text-xs text-slate-400 truncate">{registeredTeam.leader_email}</div>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-slate-400 font-bold block mb-1">Leader Phone</span>
                  <div className="text-sm font-semibold text-white">{registeredTeam.leader_phone}</div>
                  <div className="text-xs text-slate-400">Primary Contact</div>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-slate-400 font-bold block mb-1">Squad Roster</span>
                  <div className="text-sm font-semibold text-emerald-400 font-mono">12 Verified Members</div>
                  <div className="text-xs text-slate-400">Same College Verified</div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                <div className="text-xs text-slate-400">
                  Registered on: <span className="text-slate-200 font-mono">{registeredTeam.created_at}</span>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => window.print()} className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium text-xs flex items-center gap-2 transition-all cursor-pointer">
                    <Printer className="w-4 h-4" /> Print Receipt
                  </button>
                  <button onClick={() => setView('form')} className="px-5 py-2 rounded-xl bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 hover:scale-105 transition-all cursor-pointer">
                    Register Another Team
                  </button>
                </div>
              </div>

            </div>

            {/* 12 Members Grid */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider m-0">12 Verified Team Members</h3>
                <span className="text-xs text-emerald-400 font-mono">12 / 12 Verified</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {registeredTeam.members.map(m => (
                  <div key={m.id} className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col justify-between space-y-3 hover:bg-white/10 transition-colors">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-300 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                          {String(m.member_number).padStart(2, '0')}
                        </div>
                        <div className="truncate">
                          <div className="text-xs font-semibold text-white truncate">{m.full_name}</div>
                          <div className="text-[9px] text-slate-400 truncate">{m.department} - {m.year_of_study}</div>
                        </div>
                      </div>

                      <div className="text-[10px] text-slate-300 space-y-0.5 bg-black/20 p-2 rounded-xl border border-white/5">
                        <div className="truncate"><span className="text-slate-500">Email:</span> {m.college_email}</div>
                        <div><span className="text-slate-500">Phone:</span> {m.phone_number}</div>
                      </div>
                    </div>

                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-1">Sub-Events</span>
                      <div className="flex flex-wrap gap-1">
                        {m.sub_events.length > 0 ? (
                          m.sub_events.map(se => (
                            <span key={se} className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] rounded uppercase font-mono">
                              {se}
                            </span>
                          ))
                        ) : (
                          <span className="text-[9px] text-slate-500 italic">None</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* VIEW 3: ADMIN ORGANIZER DASHBOARD */}
        {view === 'admin' && (
          <div className="space-y-6">
            
            {!adminAuth ? (
              /* Password Gate */
              <div className="max-w-md mx-auto my-12 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-bold text-white tracking-tight">Organizer Portal</h2>
                  <p className="text-xs text-slate-400">Enter password to manage team registrations</p>
                </div>

                {adminError && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{adminError}</span>
                  </div>
                )}

                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[11px] uppercase tracking-wider text-slate-300 font-bold block">Admin Password</label>
                    <input 
                      type="password" 
                      value={adminPassword}
                      onChange={e => setAdminPassword(e.target.value)}
                      placeholder="Enter admin password (default: admin123)"
                      className="w-full bg-slate-900/80 border border-white/15 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-emerald-400"
                      required
                    />
                  </div>

                  <button type="submit" className="w-full py-3 bg-emerald-400 text-slate-950 font-bold rounded-xl shadow-lg shadow-emerald-400/20 hover:scale-[1.02] active:scale-[0.98] transition-all text-sm flex items-center justify-center gap-2 cursor-pointer">
                    <ArrowRight className="w-4 h-4" /> Authenticate
                  </button>
                </form>
              </div>
            ) : (
              /* Admin Portal Content */
              <div className="space-y-6">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                  <div>
                    <span className="text-emerald-400 text-xs font-bold tracking-[0.3em] uppercase">Organizer Control Center</span>
                    <h2 className="text-2xl font-bold text-white tracking-tight m-0">Registered Teams <span className="font-normal text-slate-400">Dashboard</span></h2>
                  </div>

                  <div className="flex items-center gap-3">
                    <button onClick={handleExportCSV} className="px-4 py-2.5 rounded-2xl bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-400/20 hover:scale-105 transition-all cursor-pointer">
                      <Download className="w-4 h-4" /> Export All CSV
                    </button>
                    <button onClick={() => setAdminAuth(false)} className="px-4 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-medium text-xs flex items-center gap-1.5 transition-colors cursor-pointer">
                      Logout
                    </button>
                  </div>
                </div>

                {/* Metric Summary Banner */}
                {adminStats && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">Total Teams</span>
                      <div className="text-3xl font-bold text-emerald-400 font-mono">{adminStats.totalTeams}</div>
                    </div>
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 space-y-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">Total Students</span>
                      <div className="text-3xl font-bold text-indigo-400 font-mono">{adminStats.totalMembers}</div>
                    </div>
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 space-y-1 sm:col-span-2">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1">Sub-Event Participation</span>
                      <div className="flex flex-wrap gap-2 text-xs">
                        {SUB_EVENTS.map(ev => (
                          <span key={ev.id} className="px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg text-slate-200">
                            {ev.name}: <strong className="text-emerald-400 font-mono">{adminStats.eventCounts[ev.name] || 0}</strong>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Search Box */}
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      value={adminSearch} 
                      onChange={e => setAdminSearch(e.target.value)}
                      placeholder="Search teams by team name, college, email, or registration ID..."
                      className="w-full bg-slate-900/80 border border-white/15 rounded-xl pl-10 pr-4 py-2.5 text-white text-xs focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>

                {/* Teams List */}
                <div className="space-y-4">
                  {adminTeams.length > 0 ? (
                    adminTeams.map(t => (
                      <div key={t.id} className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 hover:border-emerald-500/30 transition-all space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
                          <div className="flex items-center gap-3">
                            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 font-mono font-bold text-xs rounded-lg border border-emerald-500/30">
                              {t.reg_id}
                            </span>
                            <div>
                              <h3 className="text-base font-bold text-white m-0">{t.team_name}</h3>
                              <p className="text-xs text-slate-400 m-0">College: <span className="text-slate-200 font-medium">{t.college_name}</span></p>
                            </div>
                          </div>

                          <div className="flex items-center gap-4 text-xs text-slate-300">
                            <div>Leader: <strong className="text-white">{t.leader_name}</strong> ({t.leader_email})</div>
                            <button 
                              onClick={() => setSelectedAdminTeam(t)}
                              className="px-3 py-1.5 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-medium hover:bg-indigo-500/30 transition-colors cursor-pointer"
                            >
                              Inspect Roster (12)
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                          {t.members.map(m => (
                            <div key={m.id} className="bg-white/5 border border-white/5 rounded-xl p-2 text-[10px]">
                              <div className="font-semibold text-white truncate">{m.full_name}</div>
                              <div className="text-slate-400 text-[9px] truncate">{m.department}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-12 text-center text-slate-400">
                      No teams registered yet or match your search query.
                    </div>
                  )}
                </div>

                {/* Selected Team Drilldown Modal */}
                {selectedAdminTeam && (
                  <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
                    <div className="bg-slate-900 border border-white/20 rounded-3xl p-6 max-w-4xl w-full space-y-6 shadow-2xl my-8">
                      <div className="flex items-center justify-between border-b border-white/10 pb-4">
                        <div>
                          <span className="text-emerald-400 text-xs font-mono font-bold uppercase">{selectedAdminTeam.reg_id}</span>
                          <h3 className="text-2xl font-bold text-white m-0">{selectedAdminTeam.team_name}</h3>
                          <p className="text-xs text-slate-400 m-0">{selectedAdminTeam.college_name}</p>
                        </div>
                        <button onClick={() => setSelectedAdminTeam(null)} className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs cursor-pointer">
                          Close
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 max-h-[60vh] overflow-y-auto pr-2">
                        {selectedAdminTeam.members.map(m => (
                          <div key={m.id} className="bg-white/5 border border-white/10 rounded-xl p-3 space-y-2">
                            <div className="text-xs font-semibold text-white">{m.full_name}</div>
                            <div className="text-[10px] text-slate-400 space-y-0.5">
                              <div>Email: {m.college_email}</div>
                              <div>Dept: {m.department} ({m.year_of_study})</div>
                              <div>Phone: {m.phone_number}</div>
                            </div>
                            <div className="flex flex-wrap gap-1 pt-1">
                              {m.sub_events.map(se => (
                                <span key={se} className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[8px] rounded uppercase font-mono">
                                  {se}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

              </div>
            )}

          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-6 mt-12 bg-slate-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-400">
          <p className="m-0">© 2026 Academic Competition Committee. Frosted Glass Registration System with SQLite & Flask / React.</p>
        </div>
      </footer>

    </div>
  );
}
