const STORAGE_KEY = 'college_events_app_db_v2';

export interface MemberInput {
  full_name: string;
  college_email: string;
  phone_number: string;
  department: string;
  year_of_study: string;
  sub_events: string[];
}

export interface TeamRecord {
  id: number;
  reg_id: string;
  college_name: string;
  team_name: string;
  leader_name: string;
  leader_email: string;
  leader_phone: string;
  created_at: string;
  members: (MemberInput & { id: number; member_number: number })[];
}

class LocalEventDatabase {
  private data: {
    teams: Array<{
      id: number;
      reg_id: string;
      college_name: string;
      team_name: string;
      leader_name: string;
      leader_email: string;
      leader_phone: string;
      created_at: string;
    }>;
    members: Array<{
      id: number;
      team_id: number;
      member_number: number;
      full_name: string;
      college_email: string;
      phone_number: string;
      department: string;
      year_of_study: string;
    }>;
    event_selections: Array<{
      id: number;
      member_id: number;
      sub_event: string;
    }>;
  };

  private nextTeamId = 1;
  private nextMemberId = 1;
  private nextEventId = 1;
  private lastInsertedId = 0;

  constructor() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        this.data = parsed.data || { teams: [], members: [], event_selections: [] };
        this.nextTeamId = parsed.nextTeamId || (this.data.teams.length > 0 ? Math.max(...this.data.teams.map(t => t.id)) + 1 : 1);
        this.nextMemberId = parsed.nextMemberId || (this.data.members.length > 0 ? Math.max(...this.data.members.map(m => m.id)) + 1 : 1);
        this.nextEventId = parsed.nextEventId || (this.data.event_selections.length > 0 ? Math.max(...this.data.event_selections.map(e => e.id)) + 1 : 1);
        return;
      } catch (e) {
        console.warn("Failed to load saved database state, initializing fresh:", e);
      }
    }
    this.data = { teams: [], members: [], event_selections: [] };
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        data: this.data,
        nextTeamId: this.nextTeamId,
        nextMemberId: this.nextMemberId,
        nextEventId: this.nextEventId
      }));
    } catch (e) {
      console.error("Storage save error:", e);
    }
  }

  run(sql: string, params: any[] = []) {
    const s = sql.trim();
    if (s.toUpperCase().startsWith('CREATE TABLE')) {
      return;
    }

    if (s.includes('INSERT INTO teams')) {
      const [reg_id, college_name, team_name, leader_name, leader_email, leader_phone, created_at] = params;
      const id = this.nextTeamId++;
      const team = {
        id,
        reg_id,
        college_name,
        team_name,
        leader_name,
        leader_email,
        leader_phone,
        created_at
      };
      this.data.teams.push(team);
      this.lastInsertedId = id;
      this.save();
      return;
    }

    if (s.includes('INSERT INTO members')) {
      const [team_id, member_number, full_name, college_email, phone_number, department, year_of_study] = params;
      const id = this.nextMemberId++;
      const member = {
        id,
        team_id,
        member_number,
        full_name,
        college_email,
        phone_number,
        department,
        year_of_study
      };
      this.data.members.push(member);
      this.lastInsertedId = id;
      this.save();
      return;
    }

    if (s.includes('INSERT INTO event_selections')) {
      const [member_id, sub_event] = params;
      const id = this.nextEventId++;
      const ev = {
        id,
        member_id,
        sub_event
      };
      this.data.event_selections.push(ev);
      this.lastInsertedId = id;
      this.save();
      return;
    }
  }

  exec(sql: string): any[] {
    const s = sql.trim();

    if (s.includes('last_insert_rowid()')) {
      return [{ columns: ['id'], values: [[this.lastInsertedId]] }];
    }

    if (s.includes('FROM members WHERE LOWER(college_email) =')) {
      const match = s.match(/'([^']+)'/);
      if (match) {
        const targetEmail = match[1].toLowerCase();
        const found = this.data.members.filter(m => m.college_email.toLowerCase() === targetEmail);
        if (found.length > 0) {
          return [{ columns: ['college_email'], values: found.map(m => [m.college_email]) }];
        }
      }
      return [];
    }

    if (s.includes('FROM teams WHERE team_name =')) {
      const match = s.match(/'([^']+)'/);
      if (match) {
        const targetName = match[1];
        const found = this.data.teams.filter(t => t.team_name === targetName);
        if (found.length > 0) {
          return [{ columns: ['id'], values: found.map(t => [t.id]) }];
        }
      }
      return [];
    }

    if (s.includes('FROM teams WHERE reg_id =')) {
      const match = s.match(/'([^']+)'/);
      if (match) {
        const targetReg = match[1];
        const found = this.data.teams.find(t => t.reg_id === targetReg);
        if (found) {
          const cols = ['id', 'reg_id', 'college_name', 'team_name', 'leader_name', 'leader_email', 'leader_phone', 'created_at'];
          const vals = [cols.map(c => (found as any)[c])];
          return [{ columns: cols, values: vals }];
        }
      }
      return [];
    }

    if (s.includes('FROM teams')) {
      if (s.includes('COUNT(*)')) {
        return [{ columns: ['COUNT(*)'], values: [[this.data.teams.length]] }];
      }

      let filtered = [...this.data.teams];
      if (s.includes('LIKE')) {
        const match = s.match(/LIKE '%([^']+)%'/i);
        if (match) {
          const q = match[1].toLowerCase();
          filtered = filtered.filter(t => 
            t.team_name.toLowerCase().includes(q) ||
            t.college_name.toLowerCase().includes(q) ||
            t.leader_email.toLowerCase().includes(q) ||
            t.reg_id.toLowerCase().includes(q)
          );
        }
      }
      filtered.sort((a, b) => b.id - a.id);
      if (filtered.length === 0) return [];

      const cols = ['id', 'reg_id', 'college_name', 'team_name', 'leader_name', 'leader_email', 'leader_phone', 'created_at'];
      const vals = filtered.map(t => cols.map(c => (t as any)[c]));
      return [{ columns: cols, values: vals }];
    }

    if (s.includes('FROM members')) {
      if (s.includes('COUNT(*)')) {
        return [{ columns: ['COUNT(*)'], values: [[this.data.members.length]] }];
      }

      const match = s.match(/team_id = (\d+)/);
      if (match) {
        const teamId = parseInt(match[1]);
        const members = this.data.members.filter(m => m.team_id === teamId);
        members.sort((a, b) => a.member_number - b.member_number);
        if (members.length === 0) return [];

        const cols = ['id', 'team_id', 'member_number', 'full_name', 'college_email', 'phone_number', 'department', 'year_of_study'];
        const vals = members.map(m => cols.map(c => (m as any)[c]));
        return [{ columns: cols, values: vals }];
      }
      return [];
    }

    if (s.includes('FROM event_selections')) {
      if (s.includes('GROUP BY sub_event')) {
        const counts: Record<string, number> = {};
        this.data.event_selections.forEach(e => {
          counts[e.sub_event] = (counts[e.sub_event] || 0) + 1;
        });
        const vals = Object.entries(counts).map(([ev, count]) => [ev, count]);
        if (vals.length === 0) return [];
        return [{ columns: ['sub_event', 'COUNT(*)'], values: vals }];
      }

      const match = s.match(/member_id = (\d+)/);
      if (match) {
        const memberId = parseInt(match[1]);
        const events = this.data.event_selections.filter(e => e.member_id === memberId);
        if (events.length === 0) return [];
        return [{ columns: ['sub_event'], values: events.map(e => [e.sub_event]) }];
      }
      return [];
    }

    return [];
  }

  export() {
    return new Uint8Array();
  }
}

const dbInstance = new LocalEventDatabase();

export async function getDb() {
  return dbInstance;
}

export function generateRegistrationId(): string {
  const code = Math.random().toString(36).substring(2, 7).toUpperCase();
  return `REG-2026-${code}`;
}

export function generateUniqueTeamName(db: any, collegeName: string): string {
  const adjectives = ["Thunder", "Apex", "Quantum", "Nexus", "Titan", "Vanguard", "Cyber", "Starlight", "Hyper", "Solar", "Aero", "Pulse", "Summit", "Velocity", "Orbital"];
  const nouns = ["Hawks", "Knights", "Innovators", "Squad", "Warriors", "Pioneers", "Falcons", "Titans", "Mavericks", "Wolves", "Dragons"];
  
  const words = collegeName.trim().split(/\s+/).filter(w => !['of', 'and', 'for', 'the'].includes(w.toLowerCase()));
  const prefix = words.length > 1 ? words.map(w => w[0]).join('').toUpperCase() : (words[0] ? words[0].substring(0, 6).toUpperCase() : "COLLEGE");

  for (let i = 0; i < 50; i++) {
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    const num = Math.floor(100 + Math.random() * 900);
    
    const choice = i % 3;
    let name = "";
    if (choice === 0) name = `${prefix} ${adj} ${noun}`;
    else if (choice === 1) name = `${prefix}-2026-Team-${num}`;
    else name = `${prefix}-${adj}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    const res = db.exec(`SELECT id FROM teams WHERE team_name = '${name.replace(/'/g, "''")}'`);
    if (res.length === 0 || res[0].values.length === 0) {
      return name;
    }
  }

  return `${prefix}-Squad-${Math.floor(1000 + Math.random() * 9000)}`;
}

export async function registerTeam(
  collegeName: string,
  leaderName: string,
  leaderEmail: string,
  leaderPhone: string,
  members: MemberInput[]
): Promise<{ success: boolean; error?: string; team?: TeamRecord }> {
  if (members.length !== 12) {
    return { success: false, error: "Registration requires details for exactly 12 members." };
  }

  const emails = members.map(m => m.college_email.trim().toLowerCase());
  if (new Set(emails).size !== 12) {
    return { success: false, error: "Duplicate email addresses found within the team member list." };
  }

  const db = await getDb();

  // Check if any email is already registered in DB
  for (const email of emails) {
    const check = db.exec(`SELECT college_email FROM members WHERE LOWER(college_email) = '${email.replace(/'/g, "''")}'`);
    if (check.length > 0 && check[0].values.length > 0) {
      return { success: false, error: `Student email '${email}' is already registered with another team.` };
    }
  }

  const regId = generateRegistrationId();
  const teamName = generateUniqueTeamName(db, collegeName);
  const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

  try {
    db.run(
      `INSERT INTO teams (reg_id, college_name, team_name, leader_name, leader_email, leader_phone, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [regId, collegeName, teamName, leaderName, leaderEmail, leaderPhone, now]
    );

    const teamIdRes = db.exec(`SELECT last_insert_rowid() as id`);
    const teamId = teamIdRes[0].values[0][0] as number;

    members.forEach((m, idx) => {
      db.run(
        `INSERT INTO members (team_id, member_number, full_name, college_email, phone_number, department, year_of_study) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [teamId, idx + 1, m.full_name.trim(), m.college_email.trim().toLowerCase(), m.phone_number.trim(), m.department.trim(), m.year_of_study.trim()]
      );

      const memberIdRes = db.exec(`SELECT last_insert_rowid() as id`);
      const memberId = memberIdRes[0].values[0][0] as number;

      m.sub_events.forEach(se => {
        db.run(
          `INSERT INTO event_selections (member_id, sub_event) VALUES (?, ?)`,
          [memberId, se]
        );
      });
    });

    const team = await getTeamByRegId(regId);
    return { success: true, team: team || undefined };
  } catch (err: any) {
    return { success: false, error: err?.message || "Failed to save team registration." };
  }
}

export async function getTeamByRegId(regId: string): Promise<TeamRecord | null> {
  const db = await getDb();
  const res = db.exec(`SELECT * FROM teams WHERE reg_id = '${regId.replace(/'/g, "''")}'`);
  if (res.length === 0 || res[0].values.length === 0) return null;

  const row = res[0].values[0];
  const columns = res[0].columns;
  const team: any = {};
  columns.forEach((col, idx) => {
    team[col] = row[idx];
  });

  // Get members
  const mRes = db.exec(`SELECT * FROM members WHERE team_id = ${team.id} ORDER BY member_number ASC`);
  const membersList: any[] = [];

  if (mRes.length > 0) {
    const mCols = mRes[0].columns;
    mRes[0].values.forEach(mRow => {
      const memberObj: any = {};
      mCols.forEach((col, idx) => {
        memberObj[col] = mRow[idx];
      });

      // Get events
      const eRes = db.exec(`SELECT sub_event FROM event_selections WHERE member_id = ${memberObj.id}`);
      const events: string[] = [];
      if (eRes.length > 0) {
        eRes[0].values.forEach(eRow => {
          events.push(eRow[0] as string);
        });
      }

      memberObj.sub_events = events;
      membersList.push(memberObj);
    });
  }

  team.members = membersList;
  return team as TeamRecord;
}

export async function getAllTeams(searchQuery: string = ""): Promise<TeamRecord[]> {
  const db = await getDb();
  let sql = `SELECT * FROM teams ORDER BY id DESC`;
  if (searchQuery.trim()) {
    const q = searchQuery.trim().toLowerCase().replace(/'/g, "''");
    sql = `SELECT * FROM teams WHERE LOWER(team_name) LIKE '%${q}%' OR LOWER(college_name) LIKE '%${q}%' OR LOWER(leader_email) LIKE '%${q}%' OR LOWER(reg_id) LIKE '%${q}%' ORDER BY id DESC`;
  }

  const res = db.exec(sql);
  if (res.length === 0) return [];

  const teams: TeamRecord[] = [];
  const columns = res[0].columns;

  for (const row of res[0].values) {
    const tObj: any = {};
    columns.forEach((col, idx) => {
      tObj[col] = row[idx];
    });

    const mRes = db.exec(`SELECT * FROM members WHERE team_id = ${tObj.id} ORDER BY member_number ASC`);
    const membersList: any[] = [];
    if (mRes.length > 0) {
      const mCols = mRes[0].columns;
      mRes[0].values.forEach(mRow => {
        const mObj: any = {};
        mCols.forEach((col, idx) => {
          mObj[col] = mRow[idx];
        });

        const eRes = db.exec(`SELECT sub_event FROM event_selections WHERE member_id = ${mObj.id}`);
        const events: string[] = [];
        if (eRes.length > 0) {
          eRes[0].values.forEach(eRow => {
            events.push(eRow[0] as string);
          });
        }
        mObj.sub_events = events;
        membersList.push(mObj);
      });
    }

    tObj.members = membersList;
    teams.push(tObj as TeamRecord);
  }

  return teams;
}

export async function getSummaryStats() {
  const db = await getDb();
  const tRes = db.exec(`SELECT COUNT(*) FROM teams`);
  const totalTeams = tRes.length > 0 ? (tRes[0].values[0][0] as number) : 0;

  const mRes = db.exec(`SELECT COUNT(*) FROM members`);
  const totalMembers = mRes.length > 0 ? (mRes[0].values[0][0] as number) : 0;

  const eRes = db.exec(`SELECT sub_event, COUNT(*) FROM event_selections GROUP BY sub_event`);
  const eventCounts: Record<string, number> = {};
  if (eRes.length > 0) {
    eRes[0].values.forEach(row => {
      eventCounts[row[0] as string] = row[1] as number;
    });
  }

  return { totalTeams, totalMembers, eventCounts };
}

export async function exportTeamsCSV(): Promise<string> {
  const teams = await getAllTeams();
  let csv = 'Registration ID,Team Name,College Name,Leader Name,Leader Email,Leader Phone,Member Number,Member Full Name,College Email,Member Phone,Department,Year of Study,Sub-Events Selected\n';

  teams.forEach(t => {
    t.members.forEach(m => {
      const eventsStr = m.sub_events.length > 0 ? m.sub_events.join('; ') : 'None';
      csv += `"${t.reg_id}","${t.team_name}","${t.college_name}","${t.leader_name}","${t.leader_email}","${t.leader_phone}",${m.member_number},"${m.full_name}","${m.college_email}","${m.phone_number}","${m.department}","${m.year_of_study}","${eventsStr}"\n`;
    });
  });

  return csv;
}
